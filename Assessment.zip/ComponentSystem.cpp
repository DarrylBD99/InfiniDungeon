#include "ComponentSystem.hpp"

namespace WM908_Assessment {

	// EntityManager Class
	EntityManager::EntityManager() {

	}

	EntityManager::~EntityManager() {
		for (Entity* entity : entityDataset) {
			delete entity;
		}
	}

	bool EntityManager::EntityExist(unsigned int id) const {
		return (entityDataset.Get(id) == nullptr);
	}

	unsigned int EntityManager::GetDatasetSize() const {
		return datasetSize;
	}

	unsigned int EntityManager::AppendEntity() {
		unsigned int id;
		for (id = 0; id < entityDataset.maxSize; id++) {
			if (entityDataset.Get(id) != nullptr) continue;

			if (id >= datasetSize) {
				datasetSize = id + 1;
			}

			entityDataset.SetValue(new Entity(id), id);
			entityDataset.Get(id)->SetEntityID(id);
			break;
		}

		return id;
	}

	void EntityManager::RemoveEntity(unsigned int id) {
		entityDataset.RemoveAtIndex(id);

		ResetDatasetSize();
	}

	void EntityManager::RemoveEntities(unsigned int id[], unsigned int size) {
		for (unsigned int idx = 0; idx < size; idx++) {
			entityDataset.RemoveAtIndex(id[idx]);
		}

		ResetDatasetSize();
	}

	Entity* EntityManager::GetEntityData(unsigned int entityID) const {
		return entityDataset.Get(entityID);
	}

	void EntityManager::ResetDatasetSize() {
		while (datasetSize > 0 && entityDataset.Get(datasetSize - 1) == nullptr) {
			datasetSize--;
		}
	}

	void s_Movement::Update(unsigned int datasetSize, float deltaTime, s_Position& positionSystem) {
		for (unsigned int entityID = 0; entityID < datasetSize; entityID++) {
			c_Movement* movement = GetComponent(entityID);
			if (movement == nullptr) continue;

			c_Position* position = positionSystem.GetComponent(entityID);
			if (position == nullptr) continue;

			position->position += movement->velocity * movement->speed * deltaTime;
		}
	}

	void s_4Direction::UpdateDirection(c_4Direction* direction, c_Movement* movement) {
		bool isMoving = movement->velocity.Magnitude() > 0;

		if (movement->velocity.Magnitude() > 0) {
			float x = movement->velocity.GetX();
			float y = movement->velocity.GetY();
			if (movement->velocity.GetX() > 0) {
				direction->facing = Direction::Right;
			}
			else if (movement->velocity.GetX() < 0) {
				direction->facing = Direction::Left;
			}
			else if (movement->velocity.GetY() > 0) {
				direction->facing = Direction::Down;
			}
			else if (movement->velocity.GetY() < 0) {
				direction->facing = Direction::Up;
			}
		}
	}

	unsigned int s_4Direction::GetAnimationIndex(c_4Direction* direction, c_Movement* movement) {
		bool isMoving = movement->velocity.Magnitude() > 0;
		unsigned int animationIndex = direction->facing;

		if (isMoving) {
			animationIndex += 4;
		}

		return animationIndex;
	}

	void s_4Direction::Update(unsigned int datasetSize, s_Movement& movementSystem, s_AnimatedSprite& animatedSpriteSystem, s_LayeredAnimatedSprite& layeredAnimatedSpriteSystem) {
		for (unsigned int entityID = 0; entityID < datasetSize; entityID++) {
			c_4Direction* direction = GetComponent(entityID);
			if (direction == nullptr) continue;


			c_Movement* movement = movementSystem.GetComponent(entityID);
			if (movement == nullptr) continue;

			UpdateDirection(direction, movement);
			unsigned int animationIdx = GetAnimationIndex(direction, movement);

			c_AnimatedSprite* animatedSprite = animatedSpriteSystem.GetComponent(entityID);
			if (animatedSprite != nullptr) {
				animatedSpriteSystem.PlayAnimation(animatedSprite, animationIdx);
			}

			c_LayeredAnimatedSprite* layeredAnimatedSprite = layeredAnimatedSpriteSystem.GetComponent(entityID);
			if (layeredAnimatedSprite != nullptr) {
				layeredAnimatedSpriteSystem.PlayAnimationAll(layeredAnimatedSprite, animationIdx);
			}
		}
	}

	void s_AnimatedSprite::PlayAnimation(c_AnimatedSprite* animatedSprite, unsigned int animationIdx, unsigned int startFrame) {
		if (animatedSprite->currentAnimation == animationIdx) return;
		if (animationIdx > animatedSprite->GetNumberOfAnimations()) return;
		if (startFrame >= animatedSprite->GetCurrentAnimationFrameCount()) return;

		if (animatedSprite->isPlaying && !animatedSprite->CanOverwriteCurrentAnimation()) return;

		animatedSprite->currentAnimation = animationIdx;
		animatedSprite->animationFrameIndex = startFrame;
		animatedSprite->isPlaying = true;
		animatedSprite->timePassed = 0.0f;
	}

	void s_Sprite::Draw(unsigned int datasetSize, const s_Position& positionSystem, Renderer* renderer, unsigned int drawLayer) {
		for (unsigned int entityID = 0; entityID < datasetSize; entityID++) {
			c_Sprite* sprite = GetComponent(entityID);
			if (sprite == nullptr) continue;

			if (sprite->drawLayer != drawLayer) continue;

			c_Position* positionComponent = positionSystem.GetComponent(entityID);
			if (positionComponent == nullptr) continue;

			renderer->DrawSprite(positionComponent->position, sprite);
		}
	}

	void s_AnimatedSprite::Update(unsigned int datasetSize, float deltaTime, Renderer* renderer) {
		for (unsigned int entityID = 0; entityID < datasetSize; entityID++) {
			c_AnimatedSprite* animatedSprite = components.Get(entityID);
			if (animatedSprite == nullptr) continue;

			renderer->UpdateAnimationFrame(deltaTime, animatedSprite);
		}
	}

	void s_AnimatedSprite::Draw(unsigned int datasetSize, const s_Position& positionSystem, Renderer* renderer, unsigned int drawLayer) {
		for (unsigned int entityID = 0; entityID < datasetSize; entityID++) {
			c_AnimatedSprite* animatedSprite = GetComponent(entityID);
			if (animatedSprite == nullptr) continue;

			if (animatedSprite->drawLayer != drawLayer) continue;

			c_Position* positionComponent = positionSystem.GetComponent(entityID);
			if (positionComponent == nullptr) continue;

			renderer->DrawAnimatedSprite(positionComponent->position, animatedSprite);
		}
	}

	void s_LayeredAnimatedSprite::PlayAnimationLayer(c_LayeredAnimatedSprite* layeredAnimatedSprite, unsigned int layerID, unsigned int animationIdx, unsigned int startFrame) {
		c_AnimatedSprite* layer = layeredAnimatedSprite->layers[layerID];

		s_AnimatedSprite::PlayAnimation(layer, animationIdx, startFrame);
	}

	void s_LayeredAnimatedSprite::PlayAnimationAll(c_LayeredAnimatedSprite* layeredAnimatedSprite, unsigned int animationIdx, unsigned int startFrame) {
		for (unsigned int i = 0; i < layeredAnimatedSprite->numberOfLayers; i++) {
			PlayAnimationLayer(layeredAnimatedSprite, i, animationIdx, startFrame);
		}
	}

	void s_LayeredAnimatedSprite::SyncAnimationLayerFrames(c_LayeredAnimatedSprite* layeredAnimatedSprite) {
		unsigned int parentLayerIdx = layeredAnimatedSprite->parentLayerIdx;

		c_AnimatedSprite* parentLayer = layeredAnimatedSprite->layers[parentLayerIdx];

		for (unsigned int i = 0; i < layeredAnimatedSprite->numberOfLayers; i++) {
			if (i == parentLayerIdx) continue;

			PlayAnimationLayer(layeredAnimatedSprite, i, parentLayer->currentAnimation, parentLayer->animationFrameIndex);
		}
	}

	void s_LayeredAnimatedSprite::Update(unsigned int datasetSize, float deltaTime, Renderer* renderer) {
		for (unsigned int entityID = 0; entityID < datasetSize; entityID++) {
			c_LayeredAnimatedSprite* layeredAnimatedSprite = components.Get(entityID);
			if (layeredAnimatedSprite == nullptr) continue;

			SyncAnimationLayerFrames(layeredAnimatedSprite);

			for (unsigned int i = 0; i < layeredAnimatedSprite->numberOfLayers; i++) {
				renderer->UpdateAnimationFrame(deltaTime, layeredAnimatedSprite->layers[i]);
			}
		}
	}

	void s_LayeredAnimatedSprite::Draw(unsigned int datasetSize, const s_Position& positionSystem, Renderer* renderer, unsigned int drawLayer) {
		for (unsigned int entityID = 0; entityID < datasetSize; entityID++) {
			c_LayeredAnimatedSprite* layeredAnimatedSprite = GetComponent(entityID);
			if (layeredAnimatedSprite == nullptr) continue;

			if (layeredAnimatedSprite->drawLayer != drawLayer) continue;

			c_Position* positionComponent = positionSystem.GetComponent(entityID);
			if (positionComponent == nullptr) continue;

			for (unsigned int i = 0; i < layeredAnimatedSprite->numberOfLayers; i++) {
				renderer->DrawAnimatedSprite(positionComponent->position, layeredAnimatedSprite->layers[i]);
			}
		}
	}

	void s_Input::Update(unsigned int datasetSize, GamesEngineeringBase::Window& window, s_Movement& movementSystem) {
		for (unsigned int entityID = 0; entityID < datasetSize; entityID++) {
			c_Input* input = GetComponent(entityID);
			if (input == nullptr) continue;

			c_Movement* movement = movementSystem.GetComponent(entityID);
			if (movement == nullptr) continue;
			Vec2 velocity = { 0, 0 };

			velocity += {window.keyPressed(input->keyRight), window.keyPressed(input->keyDown)};
			velocity -= {window.keyPressed(input->keyLeft), window.keyPressed(input->keyUp)};
			movement->velocity = velocity.Normalize();
		}
	}
}