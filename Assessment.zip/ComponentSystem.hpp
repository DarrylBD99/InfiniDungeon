#pragma once
#include "Entity.hpp"
#include "Component.hpp"
#include "Dataset.hpp"
#include "Renderer.hpp"

namespace WM908_Assessment {

	class EntityManager {
	private:
		unsigned int datasetSize;
		Dataset::Array<Entity*> entityDataset;
		void ResetDatasetSize();

	public:
		EntityManager();
		~EntityManager();

		bool EntityExist(unsigned int id) const;

		unsigned int GetDatasetSize() const;

		unsigned int AppendEntity();
		Entity* GetEntityData(unsigned int entityID) const;
		void RemoveEntity(unsigned int id);
		void RemoveEntities(unsigned int id[], unsigned int size);
	};

	template<class C>
	class ComponentSystem {
	protected:
		Dataset::Array<C*> components;
	public:

		C* AddComponent(unsigned int entityID) {
			C* component = new C();
			components.SetValue(component, entityID);
			return component;
		}

		C* GetComponent(unsigned int entityID) const {
			return components.Get(entityID);
		}

		void DeleteComponent(unsigned int entityID) {
			delete components.Get(entityID);
			components.SetValue(nullptr, entityID);
		}

		void DeleteComponents(unsigned int entityID[], unsigned int size) {
			for (unsigned int idx = 0; idx < size; idx++) {
				delete components.Get(entityID[idx]);
				components.SetValue(nullptr, entityID[idx]);
			}
		}

		~ComponentSystem() {
			for (C* component : components) {
				delete component;
			}
		}
	};

	class s_Position : public ComponentSystem<c_Position> {
	public:
		//c_Position* AddComponent(unsigned int entityID, const Vec2 position) {
		//	c_Position* component = ComponentSystem<c_Position>::AddComponent(entityID);
		//	component->position = position;

		//	return component;
		//}

	};

	class s_Movement : public ComponentSystem<c_Movement> {
	public:
		void Update(unsigned int datasetSize, float deltaTime, s_Position& positionSystem);
	};

	class s_Sprite : public ComponentSystem<c_Sprite> {
	public:
		c_Sprite* AddComponent(unsigned int entityID, unsigned int spritesheetID, unsigned int drawLayer) {
			c_Sprite* component = ComponentSystem<c_Sprite>::AddComponent(entityID);
			component->spritesheetID = spritesheetID;
			component->drawLayer = drawLayer;

			return component;
		}
		void Draw(unsigned int datasetSize, const s_Position& positionSystem, Renderer* renderer, unsigned int drawLayer);
	};

	class s_AnimatedSprite : public ComponentSystem<c_AnimatedSprite> {
	public:
		c_AnimatedSprite* AddComponent(unsigned int entityID, unsigned int drawLayer) {
			c_AnimatedSprite* component = ComponentSystem<c_AnimatedSprite>::AddComponent(entityID);
			component->drawLayer = drawLayer;

			return component;
		}

		static void PlayAnimation(c_AnimatedSprite* animatedSprite, unsigned int animationIdx, unsigned int startFrame = 0);

		void Update(unsigned int datasetSize, float deltaTime, Renderer* renderer);
		void Draw(unsigned int datasetSize, const s_Position& positionSystem, Renderer* renderer, unsigned int drawLayer);
	};

	class s_LayeredAnimatedSprite : public ComponentSystem<c_LayeredAnimatedSprite> {
	public:
		c_LayeredAnimatedSprite* AddComponent(unsigned int entityID, unsigned int drawLayer) {
			c_LayeredAnimatedSprite* component = ComponentSystem<c_LayeredAnimatedSprite>::AddComponent(entityID);
			component->drawLayer = drawLayer;

			return component;
		}

		void PlayAnimationLayer(c_LayeredAnimatedSprite* layeredAnimatedSprite, unsigned int layerID, unsigned int animationIdx, unsigned int startFrame = 0);
		void PlayAnimationAll(c_LayeredAnimatedSprite* layeredAnimatedSprite, unsigned int animationIdx, unsigned int startFrame = 0);
		void SyncAnimationLayerFrames(c_LayeredAnimatedSprite* layeredAnimatedSprite);

		void Update(unsigned int datasetSize, float deltaTime, Renderer* renderer);
		void Draw(unsigned int datasetSize, const s_Position& positionSystem, Renderer* renderer, unsigned int drawLayer);
	};

	class s_4Direction : public ComponentSystem<c_4Direction> {
	public:
		void UpdateDirection(c_4Direction* direction, c_Movement* movement);
		unsigned int GetAnimationIndex(c_4Direction* direction, c_Movement* movement);

		void Update(unsigned int datasetSize, s_Movement& movementSystem, s_AnimatedSprite& animatedSpriteSystem, s_LayeredAnimatedSprite& layeredAnimatedSpriteSystem);
	};

	class s_Input : public ComponentSystem<c_Input> {
	public:
		void Update(unsigned int datasetSize, GamesEngineeringBase::Window& window, s_Movement& movementSystem);
	};
}